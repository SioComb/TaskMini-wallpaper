// metrics-bridge.js (updated RAM fields)
// Requires: Node.js 18+
// Setup:
//   npm init -y
//   npm i systeminformation express cors
//   node metrics-bridge.js
const si = require('systeminformation');
const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());

async function sample() {
  const [cpu, currentLoad, mem, graphics, net] = await Promise.all([
    si.cpu(),
    si.currentLoad(),
    si.mem(),
    si.graphics(),
    si.networkStats()
  ]);

  const activeGpu = (graphics.controllers && graphics.controllers[0]) || {};
  const net0 = Array.isArray(net) ? net[0] : net;
  const downBps = (net0 && net0.rx_sec) || 0;
  const upBps   = (net0 && net0.tx_sec) || 0;

  // Memory details
  const totalMB   = Math.round(mem.total / 1048576);
  const freeMB    = Math.round(mem.available / 1048576);
  const usedMB    = Math.round(mem.used / 1048576);
  const activeMB  = Math.round((mem.active ?? mem.used) / 1048576);
  const cacheMB   = Math.round((mem.cached ?? 0) / 1048576);
  const commitMB  = Math.round(((mem.swaptotal ?? 0) - (mem.swapfree ?? 0)) / 1048576); // OS commit approx via swap use

  return {
    cpu: { name: cpu.brand, cores: cpu.physicalCores, threads: cpu.cores, usage: currentLoad.currentload },
    ram: {
      totalMB, freeMB, usedMB, activeMB, cacheMB, commitMB,
      usagePct: totalMB ? (activeMB / totalMB) * 100 : 0
    },
    gpu: { name: activeGpu.model || 'GPU', usage: activeGpu.utilizationGpu || 0,
           vramUsedMB: activeGpu.memoryUsed || 0, vramTotalMB: activeGpu.memoryTotal || 0 },
    net: { name: net0 && (net0.ifaceName || net0.iface) || 'Network', downBps, upBps }
  };
}

app.get('/metrics', async (_req, res) => {
  try {
    const data = await sample();
    res.json(data);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

const PORT = 18080;
app.listen(PORT, () => console.log(`metrics-bridge listening at http://127.0.0.1:${PORT}/metrics`));
