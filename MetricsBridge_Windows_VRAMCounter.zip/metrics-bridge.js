// metrics-bridge.js with VRAM via PerfCounter fallback
const si = require('systeminformation');
const express = require('express');
const cors = require('cors');
const { exec } = require('child_process');
const app = express();
app.use(cors());

function getGpuAdapterMemoryCounters() {
  // Returns Promise<{usedBytes:number, limitBytes:number} | null>
  return new Promise((resolve) => {
    const ps = 'Get-Counter "\\GPU Adapter Memory(*)\\Dedicated Usage","\\GPU Adapter Memory(*)\\Dedicated Limit" | Select -ExpandProperty CounterSamples | ConvertTo-Json -Compress';
    exec(`powershell -NoProfile -Command "${ps}"`, { windowsHide: true, timeout: 2000 }, (err, stdout) => {
      if (err || !stdout) return resolve(null);
      try {
        const samples = JSON.parse(stdout);
        const arr = Array.isArray(samples) ? samples : [samples];
        let used=null, limit=null;
        for (const s of arr) {
          if (typeof s.Path === 'string' && s.Path.includes('Dedicated Usage')) used = s.CookedValue;
          if (typeof s.Path === 'string' && s.Path.includes('Dedicated Limit')) limit = s.CookedValue;
        }
        if (typeof used === 'number' && typeof limit === 'number') {
          resolve({ usedBytes: used, limitBytes: limit });
        } else resolve(null);
      } catch { resolve(null); }
    });
  });
}

async function sample() {
  const [cpu, load, mem, g, nets, vramCounters] = await Promise.all([
    si.cpu(),
    si.currentLoad(),
    si.mem(),
    si.graphics(),
    si.networkStats(),
    getGpuAdapterMemoryCounters().catch(()=>null)
  ]);
  const ctrl = (g.controllers && g.controllers[0]) || {};
  const net0 = Array.isArray(nets) ? nets[0] : nets;

  // Prefer systeminformation values; fallback to perf counters
  let vramTotalMB = ctrl.memoryTotal || null;
  let vramUsedMB = ctrl.memoryUsed || null;

  if ((vramUsedMB == null || vramTotalMB == null) && vramCounters) {
    vramUsedMB = Math.round(vramCounters.usedBytes / 1048576);
    vramTotalMB = Math.round(vramCounters.limitBytes / 1048576);
  }

  return {
    cpu: { name: cpu.brand, cores: cpu.physicalCores || cpu.cores || null, threads: cpu.cores || null, usage: load.currentload },
    ram: { totalMB: Math.round(mem.total/1048576), freeMB: Math.round(mem.available/1048576), usagePct: ((mem.total-mem.available)/mem.total)*100 },
    gpu: { name: ctrl.model || 'GPU', usage: typeof ctrl.utilizationGpu==='number'?ctrl.utilizationGpu:0,
           vramUsedMB: vramUsedMB, vramTotalMB: vramTotalMB },
    net: { name: (net0 && (net0.ifaceName || net0.iface)) || 'Network', downBps: (net0 && net0.rx_sec) || 0, upBps: (net0 && net0.tx_sec) || 0 }
  };
}

app.get('/metrics', async (_req,res)=>{
  try { res.json(await sample()); }
  catch(e){ res.status(500).json({ error: e.message }); }
});

const PORT=18080;
app.listen(PORT, ()=>console.log(`metrics-bridge http://127.0.0.1:${PORT}/metrics`));
